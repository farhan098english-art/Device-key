// ============================================================
// FarhanXComputers — Data Layer with localStorage persistence
// Admin panel changes are saved to localStorage and persist
// ============================================================

// ===== DEFAULT DATA (seed) =====
const DEFAULT_PRODUCTS = [
  {
    id: "kickstart-5500gt",
    name: "Kickstart 5500GT Shadow PC Build",
    price: 43940,
    mrp: 93680,
    stock: "in",
    badge: "From ₹30000",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "RAM", "SSD", "Power Supply", "Cabinet"],
    perks: ["Free OS License Key", "Free Gift"],
    image: "images/products/kickstart-5500gt.png",
    description: "Perfect entry-level gaming PC for 1080p gaming and everyday productivity. Powered by AMD Ryzen 5 5500GT with Radeon graphics."
  },
  {
    id: "kickstart-3400g",
    name: "Kickstart 3400G Shadow PC Build",
    price: 38540,
    mrp: 97800,
    stock: "out",
    badge: "From ₹35000",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "RAM", "SSD", "Power Supply", "Cabinet"],
    perks: ["Free OS License Key", "Free Gift"],
    image: "images/products/kickstart-3400g.png",
    description: "Budget-friendly gaming PC built for casual gamers and students. AMD Ryzen 5 3400G with Vega 11 integrated graphics."
  },
  {
    id: "kickstart-5600gt",
    name: "Kickstart 5600GT Shadow PC Build",
    price: 47900,
    mrp: 102190,
    stock: "in",
    badge: "From ₹35000",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "RAM", "SSD", "Power Supply", "Cabinet"],
    perks: ["Free OS License Key", "Free Gift"],
    image: "images/products/kickstart-5600gt.png",
    description: "Step up your game with AMD Ryzen 5 5600GT. Great for 1080p gaming, streaming, and content creation."
  },
  {
    id: "kickstart-8600g",
    name: "Kickstart 8600G Shadow PC Build",
    price: 71430,
    mrp: 130190,
    stock: "in",
    badge: "From ₹40000",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "CPU Cooler", "RAM", "SSD", "Power Supply", "Cabinet"],
    perks: ["Free OS License Key", "Free Gift"],
    image: "images/products/kickstart-8600g.png",
    description: "Powerful AM5 platform build with AMD Ryzen 5 8600G. RDNA3 integrated graphics for excellent 1080p gaming without a dedicated GPU."
  },
  {
    id: "nova-r5-5500-rtx3050",
    name: "Nova R5 5500 + RTX 3050 Shadow PC Build",
    price: 65630,
    mrp: 123300,
    stock: "in",
    badge: "From ₹60000",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "RAM", "Graphics Card", "SSD", "Power Supply", "Cabinet"],
    perks: ["Free OS License Key", "Free Gift"],
    image: "images/products/nova-r5-5500-rtx3050.png",
    description: "Dedicated GPU build featuring NVIDIA RTX 3050. Ray tracing support, DLSS, and smooth 1080p gaming at high settings."
  },
  {
    id: "kickstart-8500g",
    name: "Kickstart 8500G Shadow PC Build",
    price: 59990,
    mrp: 115000,
    stock: "in",
    badge: "From ₹45000",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "CPU Cooler", "RAM", "SSD", "Power Supply", "Cabinet"],
    perks: ["Free OS License Key", "Free Gift"],
    image: "images/products/kickstart-8500g.png",
    description: "AMD Ryzen 7 8500G powered build with Zen 4 architecture. Excellent multitasking and light gaming capabilities."
  },
  {
    id: "nova-r5-5500-rx7600",
    name: "Nova R5 5500 + RX 7600 Shadow PC Build",
    price: 72990,
    mrp: 139900,
    stock: "in",
    badge: "From ₹65000",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "RAM", "Graphics Card", "SSD", "Power Supply", "Cabinet"],
    perks: ["Free OS License Key", "Free Gift"],
    image: "images/products/nova-r5-5500-rx7600.png",
    description: "AMD Radeon RX 7600 GPU build for 1080p ultra gaming. Features RDNA3 architecture with excellent power efficiency."
  },
  {
    id: "stealth-r5-5600x-rtx3050",
    name: "Stealth R5 5600X + RTX 3050 Shadow PC Build",
    price: 78990,
    mrp: 149900,
    stock: "in",
    badge: "From ₹70000",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "CPU Cooler", "RAM", "Graphics Card", "SSD", "Power Supply", "Cabinet"],
    perks: ["Free OS License Key", "Free Gift"],
    image: "images/products/stealth-r5-5600x-rtx3050.png",
    description: "High-performance build with Ryzen 5 5600X and RTX 3050. Excellent for gaming, streaming, and light content creation."
  },
  {
    id: "stealth-r5-5600-rx7600",
    name: "Stealth R5 5600 + RX 7600 Shadow PC Build",
    price: 84990,
    mrp: 165000,
    stock: "in",
    badge: "From ₹75000",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "CPU Cooler", "RAM", "Graphics Card", "SSD", "Power Supply", "Cabinet"],
    perks: ["Free OS License Key", "Free Gift"],
    image: "images/products/stealth-r5-5600-rx7600.png",
    description: "Premium 1080p gaming build with RX 7600. Smooth 100+ FPS in modern titles at high settings."
  },
  {
    id: "nano-portable-r5-5600",
    name: "Nano Portable R5 5600 Mini PC",
    price: 52990,
    mrp: 95000,
    stock: "in",
    badge: "From ₹50000",
    category: "Mini PC",
    components: ["Processor", "Motherboard", "RAM", "SSD", "Power Supply"],
    perks: ["Free OS License Key"],
    image: "images/products/nano-portable-r5-5600.png",
    description: "Compact mini PC with Ryzen 5 5600. Perfect for space-constrained setups, HTPC, and light gaming."
  },
  {
    id: "cyber-m1-r5-9600x",
    name: "Cyber M1 R5 9600X Shadow PC Build",
    price: 99990,
    mrp: 189000,
    stock: "in",
    badge: "From ₹90000",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "CPU Cooler", "RAM", "Graphics Card", "SSD", "Power Supply", "Cabinet"],
    perks: ["Free OS License Key", "Free Gift", "Free Game Pass"],
    image: "images/products/cyber-m1-r5-9600x.png",
    description: "Latest AMD Ryzen 5 9600X Zen 5 build. Cutting-edge performance for gaming and productivity. Includes premium components."
  },
  {
    id: "inferno-m4-r7-9850x3d",
    name: "Inferno M4 R7 9850X3D Beast Build",
    price: 159990,
    mrp: 289000,
    stock: "in",
    badge: "Best Seller",
    category: "Pre-Built PC",
    components: ["Processor", "Motherboard", "CPU Cooler", "RAM", "Graphics Card", "SSD", "Power Supply", "Cabinet", "RGB Fans"],
    perks: ["Free OS License Key", "Free Gift", "Free Game Pass", "Extended Warranty"],
    image: "images/products/inferno-m4-r7-9850x3d.png",
    description: "Ultimate gaming beast with AMD Ryzen 7 9850X3D featuring 3D V-Cache. Dominate every game at maximum settings with unmatched 1% low FPS."
  }
];

const DEFAULT_CATEGORIES = [
  "Speaker","Webcam","Console","Gaming Laptop","Vertical GPU Holder Bracket","Mac",
  "AI Computers","Universal Screen","External Hard Drive","Processor","Motherboard",
  "CPU Cooler","RAM","Graphics Card","Internal SSD","Hard Drive","Power Supply",
  "Cabinets","Case Fans","Custom Cables","Monitor","Keyboard","Mouse","Mousepad",
  "Headset","UPS","External SSD","Power Strip","Controller","USB Devices",
  "Racing Wheel"
];

const DEFAULT_REVIEWS = [
  { text: "Fantastic experience! Purchased a new computer online and the process was incredibly smooth. The setup was easy and the product works flawlessly. Highly recommend for anyone looking for quality computer services", name: "Arun LKO." },
  { text: "Thanks FarhanX Computers I have received my pc safe and fine no damage safely delivered and the packaging was top notch!", name: "Suman Mondal" },
  { text: "The PC is really top notch, and I really enjoyed building a custom rig from FarhanX Computers, very friendly and positive staff and always ready to help as soon as possible. FarhanX has gained one more loyal customer for life that's for sure.", name: "Rahul Pradhan" },
  { text: "Excellent customer service highly recommended to buy new Custom PC", name: "Ankit Sisodia" },
  { text: "Thnx for build such a great pc. I am Very Happy and thnx to all FarhanX team for benchmark test and superb package.", name: "Ayan Sutradhar" },
  { text: "Great service! The delivery packaging is awesome. Thought it would take 2 weeks to arrive, but everything was packed securely.", name: "Soham Ghosh" },
  { text: "The PC is in Great condition. I live in a village still they delivered me the PC in 10 days. The packaging is outstanding. Their service is very good.", name: "Krishnendu Kundu" },
  { text: "Amazing experience and sales team, they were super kind and calm inspite of my impatience for my first gaming pc.", name: "Sarah L." },
  { text: "The experience was really good from ordering the product to getting delivered the product. Customer service was so helpfull.", name: "Pranit Kumar Saha" },
  { text: "Super service. Professional packing, Fast shipping with tracking details. You can buy with confidence", name: "Ramanathan K" }
];

const DEFAULT_FAQS = [
  { q: "Do you provide warranty on pre-built PCs?", a: "Yes, all our pre-built PCs come with manufacturer warranty on individual components ranging from 1 to 3 years depending on the part." },
  { q: "How long does delivery take?", a: "Typically 5-10 business days depending on your location. Each PC is assembled, tested, and securely packed before dispatch." },
  { q: "Can I customize a pre-built PC?", a: "Yes! You can upgrade components like RAM, SSD, or GPU on any build. Contact us with your requirements." },
  { q: "Do you ship across India?", a: "Yes, we ship pan-India with insured packaging and tracking details." },
  { q: "Is the OS pre-installed?", a: "Yes, all builds come with a free OS license key and the system is ready to use out of the box." },
  { q: "What payment methods do you accept?", a: "We accept UPI, bank transfer, credit/debit cards, and EMI options on select builds." }
];

const DEFAULT_STATS = [
  { value: "15,000+", label: "ORDERS" },
  { value: "12,000+", label: "CUSTOM PC BUILDS" },
  { value: "4,000+", label: "PRODUCTS" }
];

const DEFAULT_SETTINGS = {
  siteName: "FarhanXComputers",
  siteTagline: "Pre Built Custom PC for Gaming, Editing & Workstation",
  phone: "+91-7011805001",
  email: "support@farhanxcomputers.com",
  address: "305, 3rd Floor, Gedore House, 51-52, Nehru Place, New Delhi 110019",
  hours: "11am-6pm (Mon-Sat)",
  freeShippingText: "🚚 Free shipping across India",
  instagram: "#",
  youtube: "#",
  twitter: "#",
  facebook: "#",
  adminPassword: "admin123"
};

// ===== STORAGE KEYS =====
const STORAGE_KEYS = {
  PRODUCTS: 'fxc_products',
  CATEGORIES: 'fxc_categories',
  REVIEWS: 'fxc_reviews',
  FAQS: 'fxc_faqs',
  STATS: 'fxc_stats',
  SETTINGS: 'fxc_settings',
  CART: 'fxc_cart',
  ORDERS: 'fxc_orders'
};

// ===== DATA ACCESS FUNCTIONS =====
function loadData(key, defaultData) {
  try {
    const stored = localStorage.getItem(key);
    if (stored) return JSON.parse(stored);
  } catch (e) { /* fall through to default */ }
  // Seed default data
  localStorage.setItem(key, JSON.stringify(defaultData));
  return defaultData;
}

function saveData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

// ===== PUBLIC GETTERS (used by main.js and website) =====
// These are compatibility wrappers — old code used PRODUCTS directly,
// now we load from localStorage for persistence
function getProducts() {
  return loadData(STORAGE_KEYS.PRODUCTS, DEFAULT_PRODUCTS);
}

function getCategories() {
  return loadData(STORAGE_KEYS.CATEGORIES, DEFAULT_CATEGORIES);
}

function getReviews() {
  return loadData(STORAGE_KEYS.REVIEWS, DEFAULT_REVIEWS);
}

function getFAQs() {
  return loadData(STORAGE_KEYS.FAQS, DEFAULT_FAQS);
}

function getStats() {
  return loadData(STORAGE_KEYS.STATS, DEFAULT_STATS);
}

function getSettings() {
  return loadData(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
}

// ===== EXPOSE GLOBALS FOR BACKWARD COMPATIBILITY =====
// These get loaded once on page load; admin changes will refresh via getProducts() etc.
var PRODUCTS = getProducts();
var CATEGORIES = getCategories();
var REVIEWS = getReviews();
var FAQS = getFAQs();
var STATS = getStats();

// ===== RESET FUNCTION (for admin) =====
function resetAllData() {
  localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
  localStorage.removeItem(STORAGE_KEYS.CATEGORIES);
  localStorage.removeItem(STORAGE_KEYS.REVIEWS);
  localStorage.removeItem(STORAGE_KEYS.FAQS);
  localStorage.removeItem(STORAGE_KEYS.STATS);
  localStorage.removeItem(STORAGE_KEYS.SETTINGS);
  localStorage.removeItem(STORAGE_KEYS.ORDERS);
  PRODUCTS = getProducts();
  CATEGORIES = getCategories();
  REVIEWS = getReviews();
  FAQS = getFAQs();
  STATS = getStats();
}

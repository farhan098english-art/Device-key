/* ============================================================
   FarhanXComputers — Admin Panel JavaScript
   Full CRUD for products, categories, reviews, FAQs, stats,
   settings, orders, import/export, image upload
   ============================================================ */

// ===== AUTH =====
function isLoggedIn() {
  return sessionStorage.getItem('fxc_admin_logged_in') === 'true';
}

function doLogin() {
  const password = document.getElementById('admin-password').value;
  const settings = getSettings();
  if (password === settings.adminPassword) {
    sessionStorage.setItem('fxc_admin_logged_in', 'true');
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('admin-app').style.display = 'flex';
    initAdmin();
  } else {
    document.getElementById('login-error').textContent = 'Wrong password. Try again.';
    document.getElementById('admin-password').value = '';
  }
}

function doLogout() {
  sessionStorage.removeItem('fxc_admin_logged_in');
  document.getElementById('admin-app').style.display = 'none';
  document.getElementById('login-screen').style.display = 'flex';
  document.getElementById('admin-password').value = '';
  document.getElementById('login-error').textContent = '';
}

// ===== INIT =====
function initAdmin() {
  updateClock();
  setInterval(updateClock, 1000);
  loadDashboard();
  loadProductsTable();
  loadCategoriesAdmin();
  loadReviewsAdmin();
  loadFAQsAdmin();
  loadStatsAdmin();
  loadOrdersAdmin();
  loadSettingsForm();
  populateCategoryDatalist();
}

function updateClock() {
  const now = new Date();
  const time = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
  const date = now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  const el = document.getElementById('admin-time');
  if (el) el.textContent = `${date} · ${time}`;
}

// ===== SECTION NAVIGATION =====
function showSection(name) {
  document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
  document.getElementById('sec-' + name).classList.add('active');
  document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
  const link = document.querySelector(`[data-section="${name}"]`);
  if (link) link.classList.add('active');
  const titles = {
    dashboard: 'Dashboard', products: 'Products', categories: 'Categories',
    reviews: 'Reviews', faqs: 'FAQs', stats: 'Stats', orders: 'Orders', settings: 'Settings'
  };
  document.getElementById('page-title').textContent = titles[name] || name;
  // Refresh data on section show
  if (name === 'dashboard') loadDashboard();
  if (name === 'products') loadProductsTable();
  if (name === 'categories') loadCategoriesAdmin();
  if (name === 'reviews') loadReviewsAdmin();
  if (name === 'faqs') loadFAQsAdmin();
  if (name === 'stats') loadStatsAdmin();
  if (name === 'orders') loadOrdersAdmin();
  if (name === 'settings') loadSettingsForm();
  // Close sidebar on mobile
  document.querySelector('.admin-sidebar').classList.remove('mobile-open');
}

function toggleSidebar() {
  document.querySelector('.admin-sidebar').classList.toggle('mobile-open');
}

// ===== DASHBOARD =====
function loadDashboard() {
  const products = getProducts();
  const categories = getCategories();
  const reviews = getReviews();
  const orders = loadData(STORAGE_KEYS.ORDERS, []);

  const inStock = products.filter(p => p.stock === 'in').length;
  const outStock = products.filter(p => p.stock === 'out').length;
  const totalValue = products.reduce((s, p) => s + p.price, 0);
  const revenue = orders.reduce((s, o) => s + (o.total || 0), 0);

  document.getElementById('dash-total-products').textContent = products.length;
  document.getElementById('dash-in-stock').textContent = inStock;
  document.getElementById('dash-out-stock').textContent = outStock;
  document.getElementById('dash-categories').textContent = categories.length;
  document.getElementById('dash-total-value').textContent = '₹' + totalValue.toLocaleString('en-IN');
  document.getElementById('dash-reviews').textContent = reviews.length;
  document.getElementById('dash-orders').textContent = orders.length;
  document.getElementById('dash-revenue').textContent = '₹' + revenue.toLocaleString('en-IN');

  // Recent products
  const recent = products.slice(-5).reverse();
  document.getElementById('dash-recent-products').innerHTML = recent.map(p => `
    <div class="dash-list-item">
      <img src="${p.image}" alt="" onerror="this.style.display='none'" style="width:40px;height:40px;border-radius:6px;object-fit:cover">
      <div>
        <div style="font-weight:600">${p.name}</div>
        <div style="color:var(--text-muted);font-size:13px">${formatPrice(p.price)} · ${p.stock === 'in' ? '✅ In Stock' : '❌ Out of Stock'}</div>
      </div>
    </div>
  `).join('') || '<p style="color:var(--text-muted)">No products yet.</p>';
}

// ===== PRODUCTS CRUD =====
function loadProductsTable() {
  const products = getProducts();
  const tbody = document.getElementById('products-tbody');
  if (!tbody) return;

  if (products.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted)">No products found. Click "Add New Product" to create one.</td></tr>';
    return;
  }

  tbody.innerHTML = products.map(p => `
    <tr>
      <td><img src="${p.image}" alt="" onerror="this.src='images/products/placeholder.png'" style="width:50px;height:50px;border-radius:6px;object-fit:cover"></td>
      <td>${p.name}</td>
      <td style="color:var(--accent);font-weight:600">${formatPrice(p.price)}</td>
      <td style="color:var(--text-muted);text-decoration:line-through">${formatPrice(p.mrp)}</td>
      <td>${p.stock === 'in' ? '<span style="color:#2ecc71">✅ In Stock</span>' : '<span style="color:#e74c3c">❌ Out of Stock</span>'}</td>
      <td>${p.category || '-'}</td>
      <td>
        <button class="action-btn edit" onclick="editProduct('${p.id}')" title="Edit">✏️</button>
        <button class="action-btn delete" onclick="deleteProduct('${p.id}')" title="Delete">🗑️</button>
      </td>
    </tr>
  `).join('');
}

function openProductModal() {
  document.getElementById('product-form').reset();
  document.getElementById('prod-id').value = '';
  document.getElementById('product-modal-title').textContent = 'Add Product';
  document.getElementById('prod-image').value = '';
  document.getElementById('prod-image-url').value = '';
  document.getElementById('prod-image-preview').innerHTML = '<span class="placeholder-text">No image selected</span>';
  populateCategoryDatalist();
  document.getElementById('product-modal').style.display = 'flex';
}

function closeProductModal() {
  document.getElementById('product-modal').style.display = 'none';
}

function editProduct(id) {
  const products = getProducts();
  const p = products.find(x => x.id === id);
  if (!p) return;

  document.getElementById('prod-id').value = p.id;
  document.getElementById('prod-name').value = p.name;
  document.getElementById('prod-price').value = p.price;
  document.getElementById('prod-mrp').value = p.mrp;
  document.getElementById('prod-stock').value = p.stock;
  document.getElementById('prod-badge').value = p.badge || '';
  document.getElementById('prod-category').value = p.category || '';
  document.getElementById('prod-components').value = (p.components || []).join(', ');
  document.getElementById('prod-description').value = p.description || '';
  document.getElementById('prod-image').value = p.image || '';
  document.getElementById('prod-image-url').value = p.image && !p.image.startsWith('data:') ? p.image : '';
  document.getElementById('prod-image-preview').innerHTML = p.image
    ? `<img src="${p.image}" style="width:100%;height:100%;object-fit:cover;border-radius:8px" onerror="this.parentElement.innerHTML='<span class=placeholder-text>Invalid image</span>'">`
    : '<span class="placeholder-text">No image selected</span>';

  document.getElementById('product-modal-title').textContent = 'Edit Product';
  document.getElementById('product-modal').style.display = 'flex';
}

function saveProduct(event) {
  event.preventDefault();
  const id = document.getElementById('prod-id').value;
  const name = document.getElementById('prod-name').value;
  const price = parseInt(document.getElementById('prod-price').value);
  const mrp = parseInt(document.getElementById('prod-mrp').value);
  const stock = document.getElementById('prod-stock').value;
  const badge = document.getElementById('prod-badge').value;
  const category = document.getElementById('prod-category').value;
  const componentsStr = document.getElementById('prod-components').value;
  const components = componentsStr ? componentsStr.split(',').map(c => c.trim()).filter(c => c) : [];
  const description = document.getElementById('prod-description').value;
  const imageUrl = document.getElementById('prod-image-url').value.trim();
  const imageBase64 = document.getElementById('prod-image').value;
  const image = imageUrl || imageBase64 || 'images/products/placeholder.png';

  const products = getProducts();

  if (id) {
    // Edit existing
    const idx = products.findIndex(p => p.id === id);
    if (idx > -1) {
      products[idx] = { ...products[idx], name, price, mrp, stock, badge, category, components, description, image };
    }
  } else {
    // Add new
    const newId = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') + '-' + Date.now().toString(36);
    products.push({
      id: newId, name, price, mrp, stock, badge, category, components, description, image,
      perks: ["Free OS License Key"]
    });
  }

  saveData(STORAGE_KEYS.PRODUCTS, products);
  PRODUCTS = products;
  closeProductModal();
  loadProductsTable();
  loadDashboard();
  showToast('Product saved successfully!');
}

function deleteProduct(id) {
  showConfirm('Delete Product', 'Are you sure you want to delete this product? This cannot be undone.', () => {
    let products = getProducts();
    products = products.filter(p => p.id !== id);
    saveData(STORAGE_KEYS.PRODUCTS, products);
    PRODUCTS = products;
    loadProductsTable();
    loadDashboard();
    showToast('Product deleted.');
  });
}

// ===== IMAGE UPLOAD =====
function handleImageUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) {
    showToast('Image too large. Max 2MB. Use a URL instead for larger images.');
    return;
  }
  const reader = new FileReader();
  reader.onload = function(e) {
    document.getElementById('prod-image').value = e.target.result;
    document.getElementById('prod-image-url').value = '';
    document.getElementById('prod-image-preview').innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;border-radius:8px">`;
  };
  reader.readAsDataURL(file);
}

function onImageUrlInput() {
  const url = document.getElementById('prod-image-url').value.trim();
  if (url) {
    document.getElementById('prod-image').value = '';
    document.getElementById('prod-image-preview').innerHTML = `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:8px" onerror="this.parentElement.innerHTML='<span class=placeholder-text>Invalid URL</span>'">`;
  }
}

// ===== CATEGORIES =====
function loadCategoriesAdmin() {
  const categories = getCategories();
  const grid = document.getElementById('categories-admin-grid');
  if (!grid) return;
  grid.innerHTML = categories.map((cat, i) => {
    const slug = cat.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    return `
      <div class="category-admin-card">
        <img src="images/categories/${slug}.png" alt="${cat}" onerror="this.style.opacity=0.3" style="width:60px;height:60px;border-radius:8px">
        <span>${cat}</span>
        <button class="action-btn delete" onclick="deleteCategory(${i})">🗑️</button>
      </div>
    `;
  }).join('') || '<p style="color:var(--text-muted)">No categories.</p>';
}

function addCategory() {
  const name = prompt('Enter category name:');
  if (!name || !name.trim()) return;
  const categories = getCategories();
  if (categories.includes(name.trim())) {
    showToast('Category already exists!');
    return;
  }
  categories.push(name.trim());
  saveData(STORAGE_KEYS.CATEGORIES, categories);
  CATEGORIES = categories;
  loadCategoriesAdmin();
  populateCategoryDatalist();
  showToast('Category added!');
}

function deleteCategory(index) {
  showConfirm('Delete Category', 'Are you sure?', () => {
    const categories = getCategories();
    categories.splice(index, 1);
    saveData(STORAGE_KEYS.CATEGORIES, categories);
    CATEGORIES = categories;
    loadCategoriesAdmin();
    populateCategoryDatalist();
    showToast('Category deleted.');
  });
}

function populateCategoryDatalist() {
  const cats = getCategories();
  const dl = document.getElementById('category-list');
  if (dl) dl.innerHTML = cats.map(c => `<option value="${c}">`).join('');
}

// ===== REVIEWS =====
function loadReviewsAdmin() {
  const reviews = getReviews();
  const list = document.getElementById('reviews-admin-list');
  if (!list) return;
  if (reviews.length === 0) {
    list.innerHTML = '<p style="color:var(--text-muted)">No reviews yet.</p>';
    return;
  }
  list.innerHTML = reviews.map((r, i) => `
    <div class="list-card">
      <div class="list-card-main">
        <div class="review-stars">★★★★★</div>
        <p>"${r.text}"</p>
        <div style="color:var(--accent2);font-weight:600">— ${r.name}</div>
      </div>
      <div class="list-card-actions">
        <button class="action-btn edit" onclick="editReview(${i})">✏️</button>
        <button class="action-btn delete" onclick="deleteReview(${i})">🗑️</button>
      </div>
    </div>
  `).join('');
}

function openReviewModal() {
  document.getElementById('rev-index').value = '';
  document.getElementById('rev-name').value = '';
  document.getElementById('rev-text').value = '';
  document.getElementById('review-modal').style.display = 'flex';
}

function closeReviewModal() {
  document.getElementById('review-modal').style.display = 'none';
}

function editReview(index) {
  const reviews = getReviews();
  const r = reviews[index];
  if (!r) return;
  document.getElementById('rev-index').value = index;
  document.getElementById('rev-name').value = r.name;
  document.getElementById('rev-text').value = r.text;
  document.getElementById('review-modal').style.display = 'flex';
}

function saveReview(event) {
  event.preventDefault();
  const index = document.getElementById('rev-index').value;
  const name = document.getElementById('rev-name').value;
  const text = document.getElementById('rev-text').value;
  const reviews = getReviews();
  if (index !== '') {
    reviews[parseInt(index)] = { name, text };
  } else {
    reviews.push({ name, text });
  }
  saveData(STORAGE_KEYS.REVIEWS, reviews);
  REVIEWS = reviews;
  closeReviewModal();
  loadReviewsAdmin();
  loadDashboard();
  showToast('Review saved!');
}

function deleteReview(index) {
  showConfirm('Delete Review', 'Are you sure?', () => {
    const reviews = getReviews();
    reviews.splice(index, 1);
    saveData(STORAGE_KEYS.REVIEWS, reviews);
    REVIEWS = reviews;
    loadReviewsAdmin();
    loadDashboard();
    showToast('Review deleted.');
  });
}

// ===== FAQS =====
function loadFAQsAdmin() {
  const faqs = getFAQs();
  const list = document.getElementById('faqs-admin-list');
  if (!list) return;
  if (faqs.length === 0) {
    list.innerHTML = '<p style="color:var(--text-muted)">No FAQs yet.</p>';
    return;
  }
  list.innerHTML = faqs.map((f, i) => `
    <div class="list-card">
      <div class="list-card-main">
        <div style="font-weight:600;color:var(--accent2)">Q: ${f.q}</div>
        <p style="color:var(--text-muted);margin-top:4px">A: ${f.a}</p>
      </div>
      <div class="list-card-actions">
        <button class="action-btn edit" onclick="editFAQ(${i})">✏️</button>
        <button class="action-btn delete" onclick="deleteFAQ(${i})">🗑️</button>
      </div>
    </div>
  `).join('');
}

function openFAQModal() {
  document.getElementById('faq-index').value = '';
  document.getElementById('faq-q').value = '';
  document.getElementById('faq-a').value = '';
  document.getElementById('faq-modal').style.display = 'flex';
}

function closeFAQModal() {
  document.getElementById('faq-modal').style.display = 'none';
}

function editFAQ(index) {
  const faqs = getFAQs();
  const f = faqs[index];
  if (!f) return;
  document.getElementById('faq-index').value = index;
  document.getElementById('faq-q').value = f.q;
  document.getElementById('faq-a').value = f.a;
  document.getElementById('faq-modal').style.display = 'flex';
}

function saveFAQ(event) {
  event.preventDefault();
  const index = document.getElementById('faq-index').value;
  const q = document.getElementById('faq-q').value;
  const a = document.getElementById('faq-a').value;
  const faqs = getFAQs();
  if (index !== '') {
    faqs[parseInt(index)] = { q, a };
  } else {
    faqs.push({ q, a });
  }
  saveData(STORAGE_KEYS.FAQS, faqs);
  FAQS = faqs;
  closeFAQModal();
  loadFAQsAdmin();
  showToast('FAQ saved!');
}

function deleteFAQ(index) {
  showConfirm('Delete FAQ', 'Are you sure?', () => {
    const faqs = getFAQs();
    faqs.splice(index, 1);
    saveData(STORAGE_KEYS.FAQS, faqs);
    FAQS = faqs;
    loadFAQsAdmin();
    showToast('FAQ deleted.');
  });
}

// ===== STATS =====
function loadStatsAdmin() {
  const stats = getStats();
  const list = document.getElementById('stats-admin-list');
  if (!list) return;
  list.innerHTML = stats.map((s, i) => `
    <div class="stat-admin-card">
      <div class="stat-admin-value">${s.value}</div>
      <div class="stat-admin-label">${s.label}</div>
      <div class="stat-admin-actions">
        <button class="action-btn edit" onclick="editStat(${i})">✏️</button>
        <button class="action-btn delete" onclick="deleteStat(${i})">🗑️</button>
      </div>
    </div>
  `).join('') || '<p style="color:var(--text-muted)">No stats.</p>';
}

function addStat() {
  document.getElementById('stat-index').value = '';
  document.getElementById('stat-value').value = '';
  document.getElementById('stat-label').value = '';
  document.getElementById('stat-modal').style.display = 'flex';
}

function editStat(index) {
  const stats = getStats();
  const s = stats[index];
  if (!s) return;
  document.getElementById('stat-index').value = index;
  document.getElementById('stat-value').value = s.value;
  document.getElementById('stat-label').value = s.label;
  document.getElementById('stat-modal').style.display = 'flex';
}

function closeStatModal() {
  document.getElementById('stat-modal').style.display = 'none';
}

function saveStat(event) {
  event.preventDefault();
  const index = document.getElementById('stat-index').value;
  const value = document.getElementById('stat-value').value;
  const label = document.getElementById('stat-label').value;
  const stats = getStats();
  if (index !== '') {
    stats[parseInt(index)] = { value, label };
  } else {
    stats.push({ value, label });
  }
  saveData(STORAGE_KEYS.STATS, stats);
  STATS = stats;
  closeStatModal();
  loadStatsAdmin();
  showToast('Stat saved!');
}

function deleteStat(index) {
  showConfirm('Delete Stat', 'Are you sure?', () => {
    const stats = getStats();
    stats.splice(index, 1);
    saveData(STORAGE_KEYS.STATS, stats);
    STATS = stats;
    loadStatsAdmin();
    showToast('Stat deleted.');
  });
}

// ===== ORDERS =====
function loadOrdersAdmin() {
  const orders = loadData(STORAGE_KEYS.ORDERS, []);
  const list = document.getElementById('orders-admin-list');
  if (!list) return;
  if (orders.length === 0) {
    list.innerHTML = '<p style="color:var(--text-muted)">No orders yet. Orders placed on the website will appear here.</p>';
    return;
  }
  list.innerHTML = orders.map((o, i) => `
    <div class="list-card">
      <div class="list-card-main">
        <div style="display:flex;gap:12px;align-items:center;margin-bottom:8px">
          <span style="font-weight:600">Order #${i + 1}</span>
          <span style="color:var(--text-muted);font-size:13px">${o.date || 'N/A'}</span>
          <span style="color:var(--accent);font-weight:600">${formatPrice(o.total || 0)}</span>
        </div>
        <div style="color:var(--text-muted);font-size:13px">
          ${o.items || 'No items'} · Customer: ${o.customer || 'N/A'}
        </div>
      </div>
      <div class="list-card-actions">
        <button class="action-btn delete" onclick="deleteOrder(${i})">🗑️</button>
      </div>
    </div>
  `).join('');
}

function deleteOrder(index) {
  showConfirm('Delete Order', 'Are you sure?', () => {
    const orders = loadData(STORAGE_KEYS.ORDERS, []);
    orders.splice(index, 1);
    saveData(STORAGE_KEYS.ORDERS, orders);
    loadOrdersAdmin();
    loadDashboard();
    showToast('Order deleted.');
  });
}

function clearOrders() {
  showConfirm('Clear All Orders', 'This will permanently delete ALL orders. Continue?', () => {
    saveData(STORAGE_KEYS.ORDERS, []);
    loadOrdersAdmin();
    loadDashboard();
    showToast('All orders cleared.');
  });
}

// ===== SETTINGS =====
function loadSettingsForm() {
  const s = getSettings();
  document.getElementById('set-site-name').value = s.siteName || '';
  document.getElementById('set-tagline').value = s.siteTagline || '';
  document.getElementById('set-phone').value = s.phone || '';
  document.getElementById('set-email').value = s.email || '';
  document.getElementById('set-address').value = s.address || '';
  document.getElementById('set-hours').value = s.hours || '';
  document.getElementById('set-shipping').value = s.freeShippingText || '';
  document.getElementById('set-instagram').value = s.instagram || '';
  document.getElementById('set-youtube').value = s.youtube || '';
  document.getElementById('set-twitter').value = s.twitter || '';
  document.getElementById('set-facebook').value = s.facebook || '';
  document.getElementById('set-password').value = s.adminPassword || '';
}

function saveSettings(event) {
  event.preventDefault();
  const settings = {
    siteName: document.getElementById('set-site-name').value,
    siteTagline: document.getElementById('set-tagline').value,
    phone: document.getElementById('set-phone').value,
    email: document.getElementById('set-email').value,
    address: document.getElementById('set-address').value,
    hours: document.getElementById('set-hours').value,
    freeShippingText: document.getElementById('set-shipping').value,
    instagram: document.getElementById('set-instagram').value,
    youtube: document.getElementById('set-youtube').value,
    twitter: document.getElementById('set-twitter').value,
    facebook: document.getElementById('set-facebook').value,
    adminPassword: document.getElementById('set-password').value || 'admin123'
  };
  saveData(STORAGE_KEYS.SETTINGS, settings);
  showToast('Settings saved!');
}

// ===== IMPORT/EXPORT =====
function exportData() {
  const data = {
    products: getProducts(),
    categories: getCategories(),
    reviews: getReviews(),
    faqs: getFAQs(),
    stats: getStats(),
    settings: getSettings(),
    orders: loadData(STORAGE_KEYS.ORDERS, []),
    exportDate: new Date().toISOString()
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `farhanxcomputers-backup-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('Data exported!');
}

function importData(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const data = JSON.parse(e.target.result);
      showConfirm('Import Data', 'This will REPLACE all current data with the imported data. Continue?', () => {
        if (data.products) { saveData(STORAGE_KEYS.PRODUCTS, data.products); PRODUCTS = data.products; }
        if (data.categories) { saveData(STORAGE_KEYS.CATEGORIES, data.categories); CATEGORIES = data.categories; }
        if (data.reviews) { saveData(STORAGE_KEYS.REVIEWS, data.reviews); REVIEWS = data.reviews; }
        if (data.faqs) { saveData(STORAGE_KEYS.FAQS, data.faqs); FAQS = data.faqs; }
        if (data.stats) { saveData(STORAGE_KEYS.STATS, data.stats); STATS = data.stats; }
        if (data.settings) { saveData(STORAGE_KEYS.SETTINGS, data.settings); }
        if (data.orders) { saveData(STORAGE_KEYS.ORDERS, data.orders); }
        initAdmin();
        showToast('Data imported successfully!');
      });
    } catch (err) {
      showToast('Error: Invalid JSON file.');
    }
  };
  reader.readAsText(file);
  event.target.value = '';
}

// ===== RESET =====
function confirmReset() {
  showConfirm('Reset All Data', 'This will permanently delete ALL products, categories, reviews, FAQs, stats, orders, and settings — and restore the original default data. This CANNOT be undone. Continue?', () => {
    resetAllData();
    initAdmin();
    showToast('All data reset to defaults.');
  });
}

// ===== CONFIRM DIALOG =====
let confirmCallback = null;
function showConfirm(title, message, callback) {
  document.getElementById('confirm-title').textContent = title;
  document.getElementById('confirm-message').textContent = message;
  confirmCallback = callback;
  document.getElementById('confirm-dialog').style.display = 'flex';
}

function closeConfirm() {
  document.getElementById('confirm-dialog').style.display = 'none';
  confirmCallback = null;
}

document.getElementById('confirm-yes-btn').addEventListener('click', () => {
  document.getElementById('confirm-dialog').style.display = 'none';
  if (confirmCallback) confirmCallback();
  confirmCallback = null;
});

// ===== BOOT =====
if (isLoggedIn()) {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('admin-app').style.display = 'flex';
  initAdmin();
}

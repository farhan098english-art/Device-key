/* ============================================================
   FarhanXComputers — Main JavaScript
   Cart, product rendering, FAQ, search, navigation
   Uses localStorage-backed data from data.js
   ============================================================ */

// ===== CART STATE =====
let cart = JSON.parse(localStorage.getItem('fxc_cart') || '[]');

function saveCart() {
  localStorage.setItem('fxc_cart', JSON.stringify(cart));
  updateCartBadge();
  renderCartItems();
}

function updateCartBadge() {
  const badge = document.getElementById('cart-count');
  if (badge) {
    const count = cart.reduce((s, i) => s + i.qty, 0);
    badge.textContent = count;
    badge.style.display = count > 0 ? 'inline-block' : 'none';
  }
}

function addToCart(productId) {
  const products = getProducts();
  const product = products.find(p => p.id === productId);
  if (!product || product.stock === 'out') {
    showToast('Product is out of stock!');
    return;
  }
  const existing = cart.find(i => i.id === productId);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ id: product.id, name: product.name, price: product.price, image: product.image, qty: 1 });
  }
  saveCart();
  showToast(`${product.name} added to cart!`);
  openCart();
}

function removeFromCart(productId) {
  cart = cart.filter(i => i.id !== productId);
  saveCart();
}

function updateQty(productId, delta) {
  const item = cart.find(i => i.id === productId);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) {
    cart = cart.filter(i => i.id !== productId);
  }
  saveCart();
}

function cartTotal() {
  return cart.reduce((s, i) => s + i.price * i.qty, 0);
}

function formatPrice(n) {
  return '₹' + n.toLocaleString('en-IN');
}

// ===== CART DRAWER =====
function openCart() {
  document.getElementById('cart-drawer').classList.add('open');
  document.getElementById('cart-overlay').classList.add('open');
  renderCartItems();
}

function closeCart() {
  document.getElementById('cart-drawer').classList.remove('open');
  document.getElementById('cart-overlay').classList.remove('open');
}

function renderCartItems() {
  const container = document.getElementById('cart-items');
  const totalEl = document.getElementById('cart-total-amount');
  if (!container) return;

  if (cart.length === 0) {
    container.innerHTML = '<div class="cart-empty">Your cart is empty.<br><br>Browse our pre-built PCs to get started!</div>';
    if (totalEl) totalEl.textContent = formatPrice(0);
    return;
  }

  container.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img src="${item.image}" alt="${item.name}" onerror="this.style.display='none'">
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">${formatPrice(item.price)}</div>
        <div style="display:flex;align-items:center;gap:8px;margin-top:4px">
          <button onclick="updateQty('${item.id}',-1)" style="background:var(--bg-elevated);border:1px solid var(--border);color:var(--text);width:28px;height:28px;border-radius:6px;cursor:pointer;font-size:14px">−</button>
          <span style="font-size:14px;min-width:24px;text-align:center">${item.qty}</span>
          <button onclick="updateQty('${item.id}',1)" style="background:var(--bg-elevated);border:1px solid var(--border);color:var(--text);width:28px;height:28px;border-radius:6px;cursor:pointer;font-size:14px">+</button>
          <button onclick="removeFromCart('${item.id}')" class="cart-item-remove">Remove</button>
        </div>
      </div>
    </div>
  `).join('');

  if (totalEl) totalEl.textContent = formatPrice(cartTotal());
}

// ===== PRODUCT CARD RENDERER =====
function productCardHTML(p) {
  const stockBadge = p.stock === 'out'
    ? '<span class="product-badge out-of-stock">Out of Stock</span>'
    : '';
  const buttons = p.stock === 'out'
    ? `<button class="btn btn-primary" disabled>Out of Stock</button>`
    : `<button class="btn btn-primary" onclick="addToCart('${p.id}')">Add to Cart</button>
       <a href="product.html?id=${p.id}" class="btn btn-buy">Buy Now</a>`;
  return `
    <div class="product-card">
      <div class="product-card-img">
        ${stockBadge}
        <a href="product.html?id=${p.id}">
          <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.src='images/products/placeholder.png'">
        </a>
      </div>
      <div class="product-card-body">
        <div class="product-card-name">
          <a href="product.html?id=${p.id}">${p.name}</a>
        </div>
        <div class="product-card-price">
          <span class="price-current">${formatPrice(p.price)}</span>
          <span class="price-mrp">${formatPrice(p.mrp)}</span>
        </div>
        <div class="product-card-actions">
          ${buttons}
        </div>
      </div>
    </div>
  `;
}

function renderProductGrid(containerId, products) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = products.map(productCardHTML).join('');
}

// ===== CATEGORIES =====
function renderCategories(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const cats = getCategories();
  el.innerHTML = cats.map(cat => {
    const slug = cat.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    return `
      <div class="category-card">
        <img src="images/categories/${slug}.png" alt="${cat}" loading="lazy" onerror="this.style.opacity=0.3">
        <p>${cat}</p>
      </div>
    `;
  }).join('');
}

// ===== REVIEWS =====
function renderReviews(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const reviews = getReviews();
  el.innerHTML = reviews.map(r => `
    <div class="review-card">
      <div class="review-stars">★★★★★</div>
      <div class="review-text">${r.text}</div>
      <div class="review-author">${r.name}</div>
    </div>
  `).join('');
}

// ===== FAQ =====
function renderFAQ(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const faqs = getFAQs();
  el.innerHTML = faqs.map((f, i) => `
    <div class="faq-item" onclick="this.classList.toggle('open')">
      <div class="faq-q">
        ${f.q}
        <span class="icon">+</span>
      </div>
      <div class="faq-a">${f.a}</div>
    </div>
  `).join('');
}

// ===== STATS =====
function renderStats(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const stats = getStats();
  el.innerHTML = stats.map(s => `
    <div class="stat">
      <div class="stat-value">${s.value}</div>
      <div class="stat-label">${s.label}</div>
    </div>
  `).join('');
}

// ===== SEARCH =====
function searchProducts(query) {
  const products = getProducts();
  if (!query) return products;
  const q = query.toLowerCase();
  return products.filter(p =>
    p.name.toLowerCase().includes(q) ||
    (p.components || []).some(c => c.toLowerCase().includes(q)) ||
    (p.category || '').toLowerCase().includes(q)
  );
}

function handleSearch(e) {
  e.preventDefault();
  const input = e.target.querySelector('input') || document.getElementById('search-input');
  const query = input.value.trim();
  if (query) {
    window.location.href = `pre-built-pc.html?search=${encodeURIComponent(query)}`;
  }
}

// ===== TOAST =====
function showToast(msg) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  updateCartBadge();
  renderCartItems();
});

# FarhanXComputers — Website with Admin Panel

## What's New
- All images converted from SVG to PNG (no more broken images!)
- Full Admin Panel with CRUD for everything
- Data persists in browser localStorage

## Files
```
farhanxcomputers/
├── index.html          ← Homepage
├── pre-built-pc.html   ← Product listing page
├── product.html        ← Product detail page (?id=product-id)
├── about.html          ← About page
├── contact.html        ← Contact page
├── admin.html          ← Admin Panel (NEW!)
├── style.css           ← Main styles (dark gaming theme)
├── admin.css           ← Admin panel styles (NEW!)
├── data.js             ← Product data + localStorage layer
├── main.js             ← Cart, rendering, search
├── admin.js            ← Admin panel logic (NEW!)
├── README.md           ← This file
└── images/
    ├── logo.png
    ├── hero-banner.png
    ├── products/       ← 12 product images (PNG) + placeholder.png
    └── categories/     ← 31 category icons (PNG)
```

## How to Use

### Running the Website
Open `index.html` in any browser. Images will now display correctly.

### Admin Panel
1. Open `admin.html` in your browser
2. Enter password: `admin123` (change in Settings)
3. Manage everything: products, categories, reviews, FAQs, stats, orders, settings

### Admin Features
- **Dashboard**: Overview of products, stock, value, reviews, orders
- **Products**: Add/Edit/Delete products, upload images (JPG/PNG up to 2MB or URL), set price/MRP/stock/badge/category/components/description
- **Categories**: Add/Delete categories
- **Reviews**: Add/Edit/Delete customer reviews
- **FAQs**: Add/Edit/Delete frequently asked questions
- **Stats**: Add/Edit/Delete homepage statistics
- **Orders**: View orders placed on website
- **Settings**: Site name, tagline, phone, email, address, hours, social links, admin password
- **Import/Export**: Backup and restore all data as JSON

### Data Persistence
All changes made in admin panel are saved to browser localStorage. Data persists across page reloads. Use Export/Import for backups or moving data between browsers.

## Admin Password
Default: `admin123`
Change it in Admin Panel → Settings → Admin Password

## Image Upload
- Upload image files (JPG/PNG, max 2MB) — stored as base64 in localStorage
- Or paste an image URL (e.g., hosted image link)
- Images uploaded via admin replace default placeholder images

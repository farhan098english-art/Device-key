// FarhanXComputers — Data Layer with localStorage + User Auth
const DEFAULT_PRODUCTS = [
  {id:"kickstart-5500gt",name:"Kickstart 5500GT Shadow PC Build",price:43940,mrp:93680,stock:"in",badge:"From ₹30000",category:"Pre-Built PC",components:["Processor","Motherboard","RAM","SSD","Power Supply","Cabinet"],perks:["Free OS License Key","Free Gift"],image:"images/products/kickstart-5500gt.png",description:"Perfect entry-level gaming PC for 1080p gaming. Powered by AMD Ryzen 5 5500GT."},
  {id:"kickstart-3400g",name:"Kickstart 3400G Shadow PC Build",price:38540,mrp:97800,stock:"out",badge:"From ₹35000",category:"Pre-Built PC",components:["Processor","Motherboard","RAM","SSD","Power Supply","Cabinet"],perks:["Free OS License Key","Free Gift"],image:"images/products/kickstart-3400g.png",description:"Budget-friendly gaming PC. AMD Ryzen 5 3400G with Vega 11 graphics."},
  {id:"kickstart-5600gt",name:"Kickstart 5600GT Shadow PC Build",price:47900,mrp:102190,stock:"in",badge:"From ₹35000",category:"Pre-Built PC",components:["Processor","Motherboard","RAM","SSD","Power Supply","Cabinet"],perks:["Free OS License Key","Free Gift"],image:"images/products/kickstart-5600gt.png",description:"Step up with AMD Ryzen 5 5600GT. Great for 1080p gaming and streaming."},
  {id:"kickstart-8600g",name:"Kickstart 8600G Shadow PC Build",price:71430,mrp:130190,stock:"in",badge:"From ₹40000",category:"Pre-Built PC",components:["Processor","Motherboard","CPU Cooler","RAM","SSD","Power Supply","Cabinet"],perks:["Free OS License Key","Free Gift"],image:"images/products/kickstart-8600g.png",description:"AM5 platform with AMD Ryzen 5 8600G. RDNA3 graphics for excellent 1080p gaming."},
  {id:"nova-r5-5500-rtx3050",name:"Nova R5 5500 + RTX 3050 Shadow PC Build",price:65630,mrp:123300,stock:"in",badge:"From ₹60000",category:"Pre-Built PC",components:["Processor","Motherboard","RAM","Graphics Card","SSD","Power Supply","Cabinet"],perks:["Free OS License Key","Free Gift"],image:"images/products/nova-r5-5500-rtx3050.png",description:"Dedicated GPU with NVIDIA RTX 3050. Ray tracing and DLSS support."},
  {id:"kickstart-8500g",name:"Kickstart 8500G Shadow PC Build",price:59990,mrp:115000,stock:"in",badge:"From ₹45000",category:"Pre-Built PC",components:["Processor","Motherboard","CPU Cooler","RAM","SSD","Power Supply","Cabinet"],perks:["Free OS License Key","Free Gift"],image:"images/products/kickstart-8500g.png",description:"AMD Ryzen 7 8500G with Zen 4 architecture. Excellent multitasking."},
  {id:"nova-r5-5500-rx7600",name:"Nova R5 5500 + RX 7600 Shadow PC Build",price:72990,mrp:139900,stock:"in",badge:"From ₹65000",category:"Pre-Built PC",components:["Processor","Motherboard","RAM","Graphics Card","SSD","Power Supply","Cabinet"],perks:["Free OS License Key","Free Gift"],image:"images/products/nova-r5-5500-rx7600.png",description:"AMD Radeon RX 7600 GPU for 1080p ultra gaming. RDNA3 architecture."},
  {id:"stealth-r5-5600x-rtx3050",name:"Stealth R5 5600X + RTX 3050 Shadow PC Build",price:78990,mrp:149900,stock:"in",badge:"From ₹70000",category:"Pre-Built PC",components:["Processor","Motherboard","CPU Cooler","RAM","Graphics Card","SSD","Power Supply","Cabinet"],perks:["Free OS License Key","Free Gift"],image:"images/products/stealth-r5-5600x-rtx3050.png",description:"Ryzen 5 5600X and RTX 3050. Great for gaming, streaming and content creation."},
  {id:"stealth-r5-5600-rx7600",name:"Stealth R5 5600 + RX 7600 Shadow PC Build",price:84990,mrp:165000,stock:"in",badge:"From ₹75000",category:"Pre-Built PC",components:["Processor","Motherboard","CPU Cooler","RAM","Graphics Card","SSD","Power Supply","Cabinet"],perks:["Free OS License Key","Free Gift"],image:"images/products/stealth-r5-5600-rx7600.png",description:"Premium 1080p gaming with RX 7600. 100+ FPS in modern titles."},
  {id:"nano-portable-r5-5600",name:"Nano Portable R5 5600 Mini PC",price:52990,mrp:95000,stock:"in",badge:"From ₹50000",category:"Mini PC",components:["Processor","Motherboard","RAM","SSD","Power Supply"],perks:["Free OS License Key"],image:"images/products/nano-portable-r5-5600.png",description:"Compact mini PC with Ryzen 5 5600. Perfect for space-constrained setups."},
  {id:"cyber-m1-r5-9600x",name:"Cyber M1 R5 9600X Shadow PC Build",price:99990,mrp:189000,stock:"in",badge:"From ₹90000",category:"Pre-Built PC",components:["Processor","Motherboard","CPU Cooler","RAM","Graphics Card","SSD","Power Supply","Cabinet"],perks:["Free OS License Key","Free Gift","Free Game Pass"],image:"images/products/cyber-m1-r5-9600x.png",description:"AMD Ryzen 5 9600X Zen 5 build. Cutting-edge performance for gaming."},
  {id:"inferno-m4-r7-9850x3d",name:"Inferno M4 R7 9850X3D Beast Build",price:159990,mrp:289000,stock:"in",badge:"Best Seller",category:"Pre-Built PC",components:["Processor","Motherboard","CPU Cooler","RAM","Graphics Card","SSD","Power Supply","Cabinet","RGB Fans"],perks:["Free OS License Key","Free Gift","Free Game Pass","Extended Warranty"],image:"images/products/inferno-m4-r7-9850x3d.png",description:"Ultimate gaming beast with Ryzen 7 9850X3D featuring 3D V-Cache."}
];
const DEFAULT_CATEGORIES = ["Speaker","Webcam","Console","Gaming Laptop","Vertical GPU Holder Bracket","Mac","AI Computers","Universal Screen","External Hard Drive","Processor","Motherboard","CPU Cooler","RAM","Graphics Card","Internal SSD","Hard Drive","Power Supply","Cabinets","Case Fans","Custom Cables","Monitor","Keyboard","Mouse","Mousepad","Headset","UPS","External SSD","Power Strip","Controller","USB Devices","Racing Wheel"];
const DEFAULT_REVIEWS = [
  {text:"Fantastic experience! Purchased a new computer online and the process was incredibly smooth. Highly recommend!",name:"Arun LKO."},
  {text:"Thanks FarhanX Computers I have received my pc safe and fine no damage safely delivered!",name:"Suman Mondal"},
  {text:"The PC is really top notch. FarhanX has gained one more loyal customer for life.",name:"Rahul Pradhan"},
  {text:"Excellent customer service highly recommended to buy new Custom PC",name:"Ankit Sisodia"},
  {text:"Thnx for build such a great pc. I am Very Happy and thnx to all FarhanX team.",name:"Ayan Sutradhar"},
  {text:"Great service! The delivery packaging is awesome.",name:"Soham Ghosh"},
  {text:"The PC is in Great condition. The packaging is outstanding. Their service is very good.",name:"Krishnendu Kundu"},
  {text:"Amazing experience and sales team, super kind and calm.",name:"Sarah L."},
  {text:"The experience was really good from ordering to delivery. Customer service was helpful.",name:"Pranit Kumar Saha"},
  {text:"Super service. Professional packing, Fast shipping. Buy with confidence!",name:"Ramanathan K"}
];
const DEFAULT_FAQS = [
  {q:"Do you provide warranty on pre-built PCs?",a:"Yes, all our pre-built PCs come with manufacturer warranty on individual components ranging from 1 to 3 years."},
  {q:"How long does delivery take?",a:"Typically 5-10 business days. Each PC is assembled, tested, and securely packed before dispatch."},
  {q:"Can I customize a pre-built PC?",a:"Yes! You can upgrade components like RAM, SSD, or GPU. Contact us with your requirements."},
  {q:"Do you ship across India?",a:"Yes, we ship pan-India with insured packaging and tracking."},
  {q:"Is the OS pre-installed?",a:"Yes, all builds come with a free OS license key and ready to use out of the box."},
  {q:"What payment methods do you accept?",a:"We accept UPI (any UPI app), and Cash on Delivery (20% advance via UPI)."}
];
const DEFAULT_STATS = [{value:"15,000+",label:"ORDERS"},{value:"12,000+",label:"CUSTOM PC BUILDS"},{value:"4,000+",label:"PRODUCTS"}];
const DEFAULT_SETTINGS = {
  siteName:"FarhanXComputers",siteTagline:"Pre Built Custom PC for Gaming, Editing & Workstation",
  phone:"+91-7011805001",email:"support@farhanxcomputers.com",
  address:"305, 3rd Floor, Gedore House, 51-52, Nehru Place, New Delhi 110019",
  hours:"11am-6pm (Mon-Sat)",freeShippingText:"🚚 Free shipping across India",
  instagram:"#",youtube:"#",twitter:"#",facebook:"#",
  adminPassword:"admin123",upiId:"mdfarhan2005@fam",ownerEmail:"mdfarhan200@gmail.com",
  backgroundImage:"",primaryColor:"#e94560",accentColor:"#00b4d8"
};

const STORAGE_KEYS = {PRODUCTS:'fxc_products',CATEGORIES:'fxc_categories',REVIEWS:'fxc_reviews',FAQS:'fxc_faqs',STATS:'fxc_stats',SETTINGS:'fxc_settings',CART:'fxc_cart',ORDERS:'fxc_orders',USERS:'fxc_users',CURRENT_USER:'fxc_current_user'};

function loadData(key, def) { try { const s = localStorage.getItem(key); if (s) return JSON.parse(s); } catch(e) {} localStorage.setItem(key, JSON.stringify(def)); return def; }
function saveData(key, data) { localStorage.setItem(key, JSON.stringify(data)); }

function getProducts() { return loadData(STORAGE_KEYS.PRODUCTS, DEFAULT_PRODUCTS); }
function getCategories() { return loadData(STORAGE_KEYS.CATEGORIES, DEFAULT_CATEGORIES); }
function getReviews() { return loadData(STORAGE_KEYS.REVIEWS, DEFAULT_REVIEWS); }
function getFAQs() { return loadData(STORAGE_KEYS.FAQS, DEFAULT_FAQS); }
function getStats() { return loadData(STORAGE_KEYS.STATS, DEFAULT_STATS); }
function getSettings() { return loadData(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS); }

// ===== USER AUTH =====
function getUsers() { return loadData(STORAGE_KEYS.USERS, []); }
function registerUser(name, email, phone, password) {
  const users = getUsers();
  if (users.find(u => u.email === email)) return {success:false, message:"Email already registered"};
  const user = {id:'u'+Date.now(), name, email, phone, password, address:'', city:'', pincode:''};
  users.push(user);
  saveData(STORAGE_KEYS.USERS, users);
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  return {success:true, user};
}
function loginUser(email, password) {
  const users = getUsers();
  const user = users.find(u => u.email === email && u.password === password);
  if (!user) return {success:false, message:"Invalid email or password"};
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  return {success:true, user};
}
function logoutUser() { localStorage.removeItem(STORAGE_KEYS.CURRENT_USER); }
function getCurrentUser() { try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.CURRENT_USER)); } catch(e) { return null; } }
function isUserLoggedIn() { return getCurrentUser() !== null; }
function updateUserProfile(updates) {
  const user = getCurrentUser(); if (!user) return;
  const users = getUsers();
  const idx = users.findIndex(u => u.id === user.id);
  if (idx > -1) { users[idx] = {...users[idx], ...updates}; saveData(STORAGE_KEYS.USERS, users); localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(users[idx])); }
}

// ===== ORDERS =====
function saveOrder(order) {
  const orders = loadData(STORAGE_KEYS.ORDERS, []);
  order.id = 'FXC' + Date.now().toString().slice(-8);
  order.date = new Date().toLocaleString('en-IN');
  order.status = 'pending';
  orders.push(order);
  saveData(STORAGE_KEYS.ORDERS, orders);
  return order.id;
}
function getOrderEmailBody(order) {
  const settings = getSettings();
  let body = "New Order Received!\n\n";
  body += "Order ID: " + order.id + "\n";
  body += "Date: " + order.date + "\n\n";
  body += "Customer Details:\n";
  body += "Name: " + order.customer.name + "\n";
  body += "Email: " + order.customer.email + "\n";
  body += "Phone: " + order.customer.phone + "\n";
  body += "Address: " + order.customer.address + ", " + order.customer.city + ", " + order.customer.pincode + "\n\n";
  body += "Items:\n";
  order.items.forEach(item => { body += "- " + item.name + " x" + item.qty + " = ₹" + (item.price * item.qty) + "\n"; });
  body += "\nTotal: ₹" + order.total + "\n";
  body += "Payment Method: " + order.paymentMethod + "\n";
  if (order.advanceAmount) body += "Advance Paid: ₹" + order.advanceAmount + "\n";
  body += "UTR Number: " + order.utrNumber + "\n\n";
  body += "Please verify the payment and process the order.";
  return body;
}

var PRODUCTS = getProducts();
var CATEGORIES = getCategories();
var REVIEWS = getReviews();
var FAQS = getFAQs();
var STATS = getStats();

function resetAllData() {
  Object.values(STORAGE_KEYS).forEach(k => localStorage.removeItem(k));
  PRODUCTS = getProducts(); CATEGORIES = getCategories(); REVIEWS = getReviews(); FAQS = getFAQs(); STATS = getStats();
}

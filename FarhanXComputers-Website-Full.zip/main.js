/* FarhanXComputers — Main JS with Auth, Cart, Checkout, Background */
let cart = JSON.parse(localStorage.getItem('fxc_cart') || '[]');

function saveCart(){localStorage.setItem('fxc_cart',JSON.stringify(cart));updateCartBadge();renderCartItems();}
function updateCartBadge(){const b=document.getElementById('cart-count');if(b){const c=cart.reduce((s,i)=>s+i.qty,0);b.textContent=c;b.style.display=c>0?'inline-block':'none';}}
function addToCart(pid){const products=getProducts();const p=products.find(x=>x.id===pid);if(!p||p.stock==='out'){showToast('Out of stock!');return;}const e=cart.find(i=>i.id===pid);if(e)e.qty++;else cart.push({id:p.id,name:p.name,price:p.price,image:p.image,qty:1});saveCart();showToast(p.name+' added!');openCart();}
function removeFromCart(pid){cart=cart.filter(i=>i.id!==pid);saveCart();}
function updateQty(pid,d){const i=cart.find(x=>x.id===pid);if(!i)return;i.qty+=d;if(i.qty<=0)cart=cart.filter(x=>x.id!==pid);saveCart();}
function cartTotal(){return cart.reduce((s,i)=>s+i.price*i.qty,0);}
function formatPrice(n){return '₹'+n.toLocaleString('en-IN');}

function openCart(){document.getElementById('cart-drawer').classList.add('open');document.getElementById('cart-overlay').classList.add('open');renderCartItems();}
function closeCart(){document.getElementById('cart-drawer').classList.remove('open');document.getElementById('cart-overlay').classList.remove('open');}

function renderCartItems(){
const c=document.getElementById('cart-items');const t=document.getElementById('cart-total-amount');
if(!c)return;
if(cart.length===0){c.innerHTML='<div class="cart-empty">Your cart is empty.<br><br><a href="pre-built-pc.html" style="color:var(--accent2)">Browse PCs →</a></div>';if(t)t.textContent=formatPrice(0);return;}
c.innerHTML=cart.map(item=>`
<div class="cart-item">
<img src="${item.image}" alt="${item.name}" onerror="this.src='images/products/placeholder.png'">
<div class="cart-item-info">
<div class="cart-item-name">${item.name}</div>
<div class="cart-item-price">${formatPrice(item.price)}</div>
<div style="display:flex;align-items:center;gap:8px;margin-top:4px">
<button onclick="updateQty('${item.id}',-1)" class="qty-btn">−</button>
<span class="qty-display">${item.qty}</span>
<button onclick="updateQty('${item.id}',1)" class="qty-btn">+</button>
<button onclick="removeFromCart('${item.id}')" class="cart-item-remove">Remove</button>
</div>
</div>
</div>`).join('');
if(t)t.textContent=formatPrice(cartTotal());
}

function productCardHTML(p){
const stockBadge=p.stock==='out'?'<span class="product-badge out-of-stock">Out of Stock</span>':'';
const buttons=p.stock==='out'?'<button class="btn btn-primary" disabled>Out of Stock</button>':
`<button class="btn btn-primary" onclick="addToCart('${p.id}')">Add to Cart</button>
<a href="product.html?id=${p.id}" class="btn btn-buy">Buy Now</a>`;
return `<div class="product-card"><div class="product-card-img">${stockBadge}
<a href="product.html?id=${p.id}"><img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.src='images/products/placeholder.png'"></a>
</div><div class="product-card-body">
<div class="product-card-name"><a href="product.html?id=${p.id}">${p.name}</a></div>
<div class="product-card-price"><span class="price-current">${formatPrice(p.price)}</span><span class="price-mrp">${formatPrice(p.mrp)}</span></div>
<div class="product-card-actions">${buttons}</div></div></div>`;
}

function renderProductGrid(id,products){const el=document.getElementById(id);if(el)el.innerHTML=products.map(productCardHTML).join('');}

function renderCategories(id){const el=document.getElementById(id);if(!el)return;const cats=getCategories();
el.innerHTML=cats.map(cat=>{const slug=cat.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
return `<div class="category-card"><img src="images/categories/${slug}.png" alt="${cat}" loading="lazy" onerror="this.style.opacity=0.3"><p>${cat}</p></div>`;}).join('');}

function renderReviews(id){const el=document.getElementById(id);if(!el)return;const r=getReviews();
el.innerHTML=r.map(r=>`<div class="review-card"><div class="review-stars">★★★★★</div><div class="review-text">${r.text}</div><div class="review-author">${r.name}</div></div>`).join('');}

function renderFAQ(id){const el=document.getElementById(id);if(!el)return;const f=getFAQs();
el.innerHTML=f.map(f=>`<div class="faq-item" onclick="this.classList.toggle('open')"><div class="faq-q">${f.q}<span class="icon">+</span></div><div class="faq-a">${f.a}</div></div>`).join('');}

function renderStats(id){const el=document.getElementById(id);if(!el)return;const s=getStats();
el.innerHTML=s.map(s=>`<div class="stat"><div class="stat-value">${s.value}</div><div class="stat-label">${s.label}</div></div>`).join('');}

function searchProducts(q){const products=getProducts();if(!q)return products;const s=q.toLowerCase();return products.filter(p=>p.name.toLowerCase().includes(s)||(p.components||[]).some(c=>c.toLowerCase().includes(s))||(p.category||'').toLowerCase().includes(s));}
function handleSearch(e){e.preventDefault();const input=e.target.querySelector('input')||document.getElementById('search-input');const q=input.value.trim();if(q)window.location.href=`pre-built-pc.html?search=${encodeURIComponent(q)}`;}

function showToast(msg){let t=document.getElementById('toast');if(!t){t=document.createElement('div');t.id='toast';t.className='toast';document.body.appendChild(t);}t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),3000);}

function checkout(){if(cart.length===0){showToast('Cart is empty!');return;}if(!isUserLoggedIn()){showToast('Please login to checkout');setTimeout(()=>window.location.href='login.html',1000);return;}window.location.href='checkout.html';}

function updateAuthUI(){
const link=document.getElementById('auth-link');
if(!link)return;
const user=getCurrentUser();
if(user){link.textContent='Logout ('+user.name+')';link.href='#';link.onclick=function(){logoutUser();showToast('Logged out');setTimeout(()=>window.location.reload(),500);return false;};}
else{link.textContent='Login';link.href='login.html';}
}

function applyBackground(){
const settings=getSettings();
if(settings.backgroundImage){
document.body.style.backgroundImage=`linear-gradient(rgba(10,10,18,0.85),rgba(10,10,18,0.9)),url('${settings.backgroundImage}')`;
document.body.style.backgroundSize='cover';
document.body.style.backgroundAttachment='fixed';
document.body.style.backgroundPosition='center';
}
if(settings.primaryColor){document.documentElement.style.setProperty('--accent',settings.primaryColor);}
if(settings.accentColor){document.documentElement.style.setProperty('--accent2',settings.accentColor);}
}

document.addEventListener('DOMContentLoaded',()=>{updateCartBadge();renderCartItems();updateAuthUI();applyBackground();});

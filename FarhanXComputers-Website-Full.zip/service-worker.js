const CACHE_NAME='farhanxcomputers-v2';
const ASSETS=['./','./index.html','./pre-built-pc.html','./product.html','./about.html','./contact.html','./login.html','./checkout.html','./admin.html','./style.css','./admin.css','./data.js','./main.js','./admin.js','./manifest.json','./images/logo.png','./images/hero-banner.png','./images/upi-qr.jpg','./images/products/placeholder.png','./images/icons/icon-192.png','./images/icons/icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(ASSETS).catch(()=>{})));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.map(key=>{if(key!==CACHE_NAME)return caches.delete(key);}))));self.clients.claim();});
self.addEventListener('fetch',e=>{
if(!e.request.url.startsWith(self.location.origin))return;
if(e.request.url.includes('/admin'))return;
e.respondWith(caches.match(e.request).then(r=>{
if(r){fetch(e.request).then(f=>{if(f&&f.status===200)caches.open(CACHE_NAME).then(c=>c.put(e.request,f.clone()));}).catch(()=>{});return r;}
return fetch(e.request).then(r=>{
if(!r||r.status!==200||r.type!=='basic')return r;
caches.open(CACHE_NAME).then(c=>c.put(e.request,r.clone()));return r;
}).catch(()=>{if(e.request.destination==='document')return caches.match('./index.html');});
}));
});

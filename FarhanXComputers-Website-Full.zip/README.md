# FarhanXComputers — Website + Admin Panel + Android App

## Features
- Dark gaming theme with customizable background image
- User login/register (localStorage)
- Checkout with UPI payment (QR code + deep link to UPI apps) and COD (20% advance)
- UTR number mandatory for order confirmation
- Order details sent to owner email
- Full admin panel: products, categories, reviews, FAQs, stats, orders, settings
- PWA support (installable as app)
- All images in PNG format

## Admin Panel
- Open admin.html, password: admin123
- Change UPI ID, owner email, background image, colors in Settings
- Add/edit/delete products with image upload
- View orders with UTR numbers

## Android APK
- FarhanXComputers.apk — install on any Android phone
- WebView wrapper around the website
- Works offline (all files bundled in APK)

## Payment Flow
1. User adds products to cart
2. Clicks Checkout → must be logged in
3. Selects UPI (full payment) or COD (20% advance)
4. UPI: QR code shown + "Pay Now" opens UPI apps (PhonePe, GPay, Paytm)
5. COD: Shows 20% advance amount, pay via UPI, rest on delivery
6. User enters UTR number (mandatory)
7. Order placed → email composed with order details for owner

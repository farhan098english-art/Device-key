/* FarhanXComputers — Admin JS (Full CRUD + Settings + Background) */
function isLoggedIn(){return sessionStorage.getItem('fxc_admin')==='true';}
function doLogin(){const p=document.getElementById('admin-password').value;const s=getSettings();if(p===s.adminPassword){sessionStorage.setItem('fxc_admin','true');document.getElementById('login-screen').style.display='none';document.getElementById('admin-app').style.display='flex';initAdmin();}else{document.getElementById('login-error').textContent='Wrong password';document.getElementById('admin-password').value='';}}
function doLogout(){sessionStorage.removeItem('fxc_admin');document.getElementById('admin-app').style.display='none';document.getElementById('login-screen').style.display='flex';}

function initAdmin(){
setInterval(()=>{const n=new Date();const el=document.getElementById('admin-time');if(el)el.textContent=n.toLocaleDateString('en-IN',{day:'2-digit',month:'short'})+' · '+n.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',hour12:true});},1000);
loadDashboard();loadProducts();loadCats();loadRevs();loadFaqs();loadStats();loadOrders();loadSettings();
}

function showSection(n){
document.querySelectorAll('.admin-section').forEach(s=>s.classList.remove('active'));
document.getElementById('sec-'+n).classList.add('active');
document.querySelectorAll('.sidebar-link').forEach(l=>l.classList.remove('active'));
const link=document.querySelector(`[data-section="${n}"]`);if(link)link.classList.add('active');
const titles={dashboard:'Dashboard',products:'Products',categories:'Categories',reviews:'Reviews',faqs:'FAQs',stats:'Stats',orders:'Orders',settings:'Settings'};
document.getElementById('page-title').textContent=titles[n]||n;
if(n==='dashboard')loadDashboard();if(n==='products')loadProducts();if(n==='categories')loadCats();if(n==='reviews')loadRevs();if(n==='faqs')loadFaqs();if(n==='stats')loadStats();if(n==='orders')loadOrders();if(n==='settings')loadSettings();
}

function loadDashboard(){
const p=getProducts(),o=loadData(STORAGE_KEYS.ORDERS,[]);
document.getElementById('d-products').textContent=p.length;
document.getElementById('d-instock').textContent=p.filter(x=>x.stock==='in').length;
document.getElementById('d-orders').textContent=o.length;
document.getElementById('d-revenue').textContent='₹'+o.reduce((s,x)=>s+(x.total||0),0).toLocaleString('en-IN');
document.getElementById('d-recent').innerHTML=p.slice(-5).reverse().map(x=>`<div class="dash-list-item"><img src="${x.image}" style="width:40px;height:40px;border-radius:6px;object-fit:cover" onerror="this.style.display='none'"><div><div style="font-weight:600">${x.name}</div><div style="color:var(--text-muted);font-size:13px">₹${x.price.toLocaleString('en-IN')}</div></div></div>`).join('')||'<p style="color:var(--text-muted)">No products.</p>';
}

function loadProducts(){
const p=getProducts();const tb=document.getElementById('products-tbody');if(!tb)return;
if(!p.length){tb.innerHTML='<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted)">No products.</td></tr>';return;}
tb.innerHTML=p.map(x=>`<tr><td><img src="${x.image}" style="width:50px;height:50px;border-radius:6px;object-fit:cover" onerror="this.src='images/products/placeholder.png'"></td><td>${x.name}</td><td style="color:var(--accent);font-weight:600">₹${x.price.toLocaleString('en-IN')}</td><td style="color:var(--text-muted);text-decoration:line-through">₹${x.mrp.toLocaleString('en-IN')}</td><td>${x.stock==='in'?'<span style="color:#2ecc71">✅ In Stock</span>':'<span style="color:#e74c3c">❌ Out</span>'}</td><td><button class="action-btn edit" onclick="editProduct('${x.id}')">✏️</button><button class="action-btn delete" onclick="deleteProduct('${x.id}')">🗑️</button></td></tr>`).join('');
}

function openProdModal(){
['p-id','p-name','p-price','p-mrp','p-badge','p-cat','p-comp','p-desc','p-img','p-img-url'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
document.getElementById('p-stock').value='in';
document.getElementById('prod-title').textContent='Add Product';
document.getElementById('p-img-prev').innerHTML='<span class="placeholder-text">No image</span>';
document.getElementById('prod-modal').style.display='flex';
}
function closeProdModal(){document.getElementById('prod-modal').style.display='none';}

function editProduct(id){
const p=getProducts().find(x=>x.id===id);if(!p)return;
document.getElementById('p-id').value=p.id;document.getElementById('p-name').value=p.name;
document.getElementById('p-price').value=p.price;document.getElementById('p-mrp').value=p.mrp;
document.getElementById('p-stock').value=p.stock;document.getElementById('p-badge').value=p.badge||'';
document.getElementById('p-cat').value=p.category||'';document.getElementById('p-comp').value=(p.components||[]).join(', ');
document.getElementById('p-desc').value=p.description||'';document.getElementById('p-img').value=p.image||'';
document.getElementById('p-img-url').value=p.image&&!p.image.startsWith('data:')?p.image:'';
document.getElementById('p-img-prev').innerHTML=p.image?`<img src="${p.image}" style="width:100%;height:100%;object-fit:cover;border-radius:8px" onerror="this.parentElement.innerHTML='<span class=placeholder-text>Invalid</span>'">`:'<span class="placeholder-text">No image</span>';
document.getElementById('prod-title').textContent='Edit Product';
document.getElementById('prod-modal').style.display='flex';
}

function saveProduct(e){
e.preventDefault();
const id=document.getElementById('p-id').value;
const name=document.getElementById('p-name').value;
const price=parseInt(document.getElementById('p-price').value);
const mrp=parseInt(document.getElementById('p-mrp').value);
const stock=document.getElementById('p-stock').value;
const badge=document.getElementById('p-badge').value;
const category=document.getElementById('p-cat').value;
const comp=document.getElementById('p-comp').value.split(',').map(c=>c.trim()).filter(c=>c);
const desc=document.getElementById('p-desc').value;
const img=document.getElementById('p-img-url').value.trim()||document.getElementById('p-img').value||'images/products/placeholder.png';
const products=getProducts();
if(id){const i=products.findIndex(p=>p.id===id);if(i>-1)products[i]={...products[i],name,price,mrp,stock,badge,category,components:comp,description:desc,image:img};}
else{products.push({id:name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'')+'-'+Date.now().toString(36),name,price,mrp,stock,badge,category,components:comp,description:desc,image:img,perks:["Free OS License Key"]});}
saveData(STORAGE_KEYS.PRODUCTS,products);PRODUCTS=products;closeProdModal();loadProducts();loadDashboard();showToast('Product saved!');
}

function deleteProduct(id){showConfirm('Delete Product','Sure?',()=>{let p=getProducts().filter(x=>x.id!==id);saveData(STORAGE_KEYS.PRODUCTS,p);PRODUCTS=p;loadProducts();loadDashboard();showToast('Deleted.');});}

function handleImgUpload(e){const f=e.target.files[0];if(!f)return;if(f.size>2*1024*1024){showToast('Max 2MB.');return;}const r=new FileReader();r.onload=ev=>{document.getElementById('p-img').value=ev.target.result;document.getElementById('p-img-url').value='';document.getElementById('p-img-prev').innerHTML=`<img src="${ev.target.result}" style="width:100%;height:100%;object-fit:cover;border-radius:8px">`;};r.readAsDataURL(f);}
function onImgUrlInput(){const u=document.getElementById('p-img-url').value.trim();if(u){document.getElementById('p-img').value='';document.getElementById('p-img-prev').innerHTML=`<img src="${u}" style="width:100%;height:100%;object-fit:cover;border-radius:8px" onerror="this.parentElement.innerHTML='<span class=placeholder-text>Invalid URL</span>'">`;}}

function loadCats(){const c=getCategories();const g=document.getElementById('cat-grid');if(!g)return;g.innerHTML=c.map((cat,i)=>{const slug=cat.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');return `<div class="category-admin-card"><img src="images/categories/${slug}.png" style="width:60px;height:60px;border-radius:8px" onerror="this.style.opacity=0.3"><span>${cat}</span><button class="action-btn delete" onclick="deleteCat(${i})">🗑️</button></div>`;}).join('')||'<p style="color:var(--text-muted)">None.</p>';}
function addCat(){const n=prompt('Category name:');if(!n||!n.trim())return;const c=getCategories();if(c.includes(n.trim())){showToast('Exists!');return;}c.push(n.trim());saveData(STORAGE_KEYS.CATEGORIES,c);CATEGORIES=c;loadCats();showToast('Added!');}
function deleteCat(i){showConfirm('Delete?','Sure?',()=>{const c=getCategories();c.splice(i,1);saveData(STORAGE_KEYS.CATEGORIES,c);CATEGORIES=c;loadCats();showToast('Deleted.');});}

function loadRevs(){const r=getReviews();const l=document.getElementById('rev-list');if(!l)return;l.innerHTML=r.length?r.map((rv,i)=>`<div class="list-card"><div class="list-card-main"><div class="review-stars">★★★★★</div><p>"${rv.text}"</p><div style="color:var(--accent2);font-weight:600">— ${rv.name}</div></div><div class="list-card-actions"><button class="action-btn edit" onclick="editRev(${i})">✏️</button><button class="action-btn delete" onclick="deleteRev(${i})">🗑️</button></div></div>`).join(''):'<p style="color:var(--text-muted)">None.</p>';}
function openRevModal(){document.getElementById('r-name').value='';document.getElementById('r-text').value='';document.getElementById('rev-modal').style.display='flex';}
function closeRevModal(){document.getElementById('rev-modal').style.display='none';}
function editRev(i){const r=getReviews()[i];if(!r)return;document.getElementById('r-name').value=r.name;document.getElementById('r-text').value=r.text;document.getElementById('rev-modal').style.display='flex';}
function saveReview(e){e.preventDefault();const n=document.getElementById('r-name').value,t=document.getElementById('r-text').value;const r=getReviews();r.push({name:n,text:t});saveData(STORAGE_KEYS.REVIEWS,r);REVIEWS=r;closeRevModal();loadRevs();showToast('Saved!');}
function deleteRev(i){showConfirm('Delete?','Sure?',()=>{const r=getReviews();r.splice(i,1);saveData(STORAGE_KEYS.REVIEWS,r);REVIEWS=r;loadRevs();showToast('Deleted.');});}

function loadFaqs(){const f=getFAQs();const l=document.getElementById('faq-list');if(!l)return;l.innerHTML=f.length?f.map((fq,i)=>`<div class="list-card"><div class="list-card-main"><div style="font-weight:600;color:var(--accent2)">Q: ${fq.q}</div><p style="color:var(--text-muted)">A: ${fq.a}</p></div><div class="list-card-actions"><button class="action-btn edit" onclick="editFaq(${i})">✏️</button><button class="action-btn delete" onclick="deleteFaq(${i})">🗑️</button></div></div>`).join(''):'<p style="color:var(--text-muted)">None.</p>';}
function openFAQModal(){document.getElementById('f-q').value='';document.getElementById('f-a').value='';document.getElementById('faq-modal').style.display='flex';}
function closeFaqModal(){document.getElementById('faq-modal').style.display='none';}
function editFaq(i){const f=getFAQs()[i];if(!f)return;document.getElementById('f-q').value=f.q;document.getElementById('f-a').value=f.a;document.getElementById('faq-modal').style.display='flex';}
function saveFAQ(e){e.preventDefault();const q=document.getElementById('f-q').value,a=document.getElementById('f-a').value;const f=getFAQs();f.push({q,a});saveData(STORAGE_KEYS.FAQS,f);FAQS=f;closeFaqModal();loadFaqs();showToast('Saved!');}
function deleteFaq(i){showConfirm('Delete?','Sure?',()=>{const f=getFAQs();f.splice(i,1);saveData(STORAGE_KEYS.FAQS,f);FAQS=f;loadFaqs();showToast('Deleted.');});}

function loadStats(){const s=getStats();const g=document.getElementById('stat-grid');if(!g)return;g.innerHTML=s.map((st,i)=>`<div style="background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:20px;text-align:center;position:relative"><div style="font-size:28px;font-weight:700;color:var(--accent2)">${st.value}</div><div style="font-size:13px;color:var(--text-muted)">${st.label}</div><div style="position:absolute;top:8px;right:8px"><button class="action-btn delete" onclick="deleteStat(${i})">🗑️</button></div></div>`).join('')||'<p style="color:var(--text-muted)">None.</p>';}
function addStat(){const v=prompt('Value:');if(!v)return;const l=prompt('Label:');if(!l)return;const s=getStats();s.push({value:v,label:l});saveData(STORAGE_KEYS.STATS,s);STATS=s;loadStats();showToast('Added!');}
function deleteStat(i){showConfirm('Delete?','Sure?',()=>{const s=getStats();s.splice(i,1);saveData(STORAGE_KEYS.STATS,s);STATS=s;loadStats();showToast('Deleted.');});}

function loadOrders(){const o=loadData(STORAGE_KEYS.ORDERS,[]);const l=document.getElementById('orders-list');if(!l)return;if(!o.length){l.innerHTML='<p style="color:var(--text-muted)">No orders yet.</p>';return;}l.innerHTML=o.map((ord,i)=>`<div class="list-card"><div class="list-card-main"><div style="font-weight:600">Order ${ord.id}</div><div style="color:var(--text-muted);font-size:13px">${ord.date} · ₹${ord.total} · ${ord.paymentMethod}</div><div style="color:var(--text-muted);font-size:13px">Customer: ${ord.customer.name} · UTR: ${ord.utrNumber}</div></div><div class="list-card-actions"><button class="action-btn delete" onclick="deleteOrder(${i})">🗑️</button></div></div>`).join('');}
function deleteOrder(i){showConfirm('Delete?','Sure?',()=>{const o=loadData(STORAGE_KEYS.ORDERS,[]);o.splice(i,1);saveData(STORAGE_KEYS.ORDERS,o);loadOrders();loadDashboard();showToast('Deleted.');});}
function clearOrders(){showConfirm('Clear All?','Delete ALL orders?',()=>{saveData(STORAGE_KEYS.ORDERS,[]);loadOrders();loadDashboard();showToast('Cleared.');});}

function loadSettings(){
const s=getSettings();
document.getElementById('set-name').value=s.siteName||'';
document.getElementById('set-phone').value=s.phone||'';
document.getElementById('set-email').value=s.email||'';
document.getElementById('set-hours').value=s.hours||'';
document.getElementById('set-address').value=s.address||'';
document.getElementById('set-upi').value=s.upiId||'';
document.getElementById('set-owner-email').value=s.ownerEmail||'';
document.getElementById('set-primary-color').value=s.primaryColor||'';
document.getElementById('set-accent-color').value=s.accentColor||'';
document.getElementById('set-ig').value=s.instagram||'';
document.getElementById('set-yt').value=s.youtube||'';
document.getElementById('set-pass').value=s.adminPassword||'';
document.getElementById('set-bg').value=s.backgroundImage||'';
document.getElementById('set-bg-url').value=s.backgroundImage&&!s.backgroundImage.startsWith('data:')?s.backgroundImage:'';
if(s.backgroundImage){document.getElementById('bg-preview').innerHTML=`<img src="${s.backgroundImage}" style="width:100%;height:100%;object-fit:cover;border-radius:8px">`;}else{document.getElementById('bg-preview').innerHTML='<span class="placeholder-text">No background</span>';}
}

function saveSettings(e){
e.preventDefault();
const settings={
siteName:document.getElementById('set-name').value,
phone:document.getElementById('set-phone').value,
email:document.getElementById('set-email').value,
hours:document.getElementById('set-hours').value,
address:document.getElementById('set-address').value,
freeShippingText:'🚚 Free shipping across India',
upiId:document.getElementById('set-upi').value||'mdfarhan2005@fam',
ownerEmail:document.getElementById('set-owner-email').value||'mdfarhan200@gmail.com',
primaryColor:document.getElementById('set-primary-color').value||'#e94560',
accentColor:document.getElementById('set-accent-color').value||'#00b4d8',
instagram:document.getElementById('set-ig').value,
youtube:document.getElementById('set-yt').value,
twitter:'#',facebook:'#',
adminPassword:document.getElementById('set-pass').value||'admin123',
backgroundImage:document.getElementById('set-bg-url').value.trim()||document.getElementById('set-bg').value||''
};
saveData(STORAGE_KEYS.SETTINGS,settings);showToast('Settings saved!');
}

function handleBgUpload(e){const f=e.target.files[0];if(!f)return;if(f.size>3*1024*1024){showToast('Max 3MB for background.');return;}const r=new FileReader();r.onload=ev=>{document.getElementById('set-bg').value=ev.target.result;document.getElementById('set-bg-url').value='';document.getElementById('bg-preview').innerHTML=`<img src="${ev.target.result}" style="width:100%;height:100%;object-fit:cover;border-radius:8px">`;};r.readAsDataURL(f);}
function onBgUrlInput(){const u=document.getElementById('set-bg-url').value.trim();if(u){document.getElementById('set-bg').value='';document.getElementById('bg-preview').innerHTML=`<img src="${u}" style="width:100%;height:100%;object-fit:cover;border-radius:8px" onerror="this.parentElement.innerHTML='<span class=placeholder-text>Invalid</span>'">`;}}

function exportData(){const d={products:getProducts(),categories:getCategories(),reviews:getReviews(),faqs:getFAQs(),stats:getStats(),settings:getSettings(),orders:loadData(STORAGE_KEYS.ORDERS,[])};const b=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download=`fxc-backup-${Date.now()}.json`;a.click();URL.revokeObjectURL(u);showToast('Exported!');}
function importData(e){const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=ev=>{try{const d=JSON.parse(ev.target.result);showConfirm('Import?','Replace all data?',()=>{if(d.products)saveData(STORAGE_KEYS.PRODUCTS,d.products);if(d.categories)saveData(STORAGE_KEYS.CATEGORIES,d.categories);if(d.reviews)saveData(STORAGE_KEYS.REVIEWS,d.reviews);if(d.faqs)saveData(STORAGE_KEYS.FAQS,d.faqs);if(d.stats)saveData(STORAGE_KEYS.STATS,d.stats);if(d.settings)saveData(STORAGE_KEYS.SETTINGS,d.settings);if(d.orders)saveData(STORAGE_KEYS.ORDERS,d.orders);initAdmin();showToast('Imported!');});}catch(err){showToast('Invalid file.');}};r.readAsText(f);e.target.value='';}

function confirmReset(){showConfirm('Reset All','Delete everything and restore defaults?',()=>{resetAllData();initAdmin();showToast('Reset done.');});}

let cb=null;
function showConfirm(t,m,fn){document.getElementById('cf-title').textContent=t;document.getElementById('cf-msg').textContent=m;cb=fn;document.getElementById('confirm-dialog').style.display='flex';}
function closeConfirm(){document.getElementById('confirm-dialog').style.display='none';cb=null;}
document.getElementById('cf-yes').addEventListener('click',()=>{document.getElementById('confirm-dialog').style.display='none';if(cb)cb();cb=null;});

function showToast(msg){let t=document.createElement('div');t.className='toast';t.textContent=msg;t.style.cssText='position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:var(--accent);color:#fff;padding:12px 24px;border-radius:8px;z-index:9999;font-size:14px;box-shadow:0 4px 16px rgba(0,0,0,0.4)';document.body.appendChild(t);setTimeout(()=>t.remove(),3000);}

if(isLoggedIn()){document.getElementById('login-screen').style.display='none';document.getElementById('admin-app').style.display='flex';initAdmin();}
